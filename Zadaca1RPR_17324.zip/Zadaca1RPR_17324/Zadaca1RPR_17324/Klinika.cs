﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Doktori;
namespace Zadaca1RPR_17324
{
    class Klinika
    {
        public string nazivKlinike;
        Doktor sefKlinike;
    }
}
